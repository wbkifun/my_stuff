ncl visual.ncl
convert -density 200  -trim map.ps map.png
display map.png
