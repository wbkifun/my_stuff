#!/bin/bash

icc -o run.x Serial_LJ_01.c
time ./run.x

