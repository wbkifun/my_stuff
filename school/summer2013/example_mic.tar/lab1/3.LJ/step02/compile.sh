#!/bin/bash

icc -mmic -o run.mic Serial_LJ_01.c

