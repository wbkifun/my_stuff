#!/bin/bash
time micnativeloadex ./run.mic