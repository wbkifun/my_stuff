import os

os.system('f2py -m vector_in_out -h  vector_in_out.pyf vector_in_out.f90')
